# CatVTON E-commerce P0 Refactor

This package is an application-layer refactor for the existing CatVTON repository.

## What P0 does

1. Upload a model/person image.
2. Upload a white-background pajama/product image.
3. Prepare a diagnostic product mask.
4. Call the original CatVTON pipeline.
5. Return a 1K/2K output.
6. Keep the original CatVTON model code unchanged.

## What P0 deliberately does NOT claim

It does not provide mathematically exact 1:1 garment pixel preservation.

A flat product photo and a posed human body have different geometry. Directly pasting the flat product image onto the generated body would be incorrect.

P1 should add:

- garment geometric warping
- dense correspondence
- product texture preservation
- optional manual mask correction
- face/identity control
- dedicated super-resolution
- batch generation
- e-commerce templates

## Installation

Clone/fork the original CatVTON repository first, then copy this package into its root:

```bash
git clone https://github.com/Zheng-Chong/CatVTON.git
cd CatVTON
# checkout the branch/ref you intend to use

cp -r /path/to/catvton_ecommerce_p0/services .
cp -r /path/to/catvton_ecommerce_p0/processors .
cp -r /path/to/catvton_ecommerce_p0/backend .
cp -r /path/to/catvton_ecommerce_p0/configs .
cp /path/to/catvton_ecommerce_p0/app.py ./app.py
cp /path/to/catvton_ecommerce_p0/requirements-p0.txt .
```

Install the original CatVTON dependencies according to its README, then:

```bash
pip install -r requirements-p0.txt
```

## Run

GPU:

```bash
python app.py --device cuda --mixed_precision bf16 --port 7860
```

If your GPU does not support BF16, try:

```bash
python app.py --device cuda --mixed_precision fp16 --port 7860
```

Open:

```text
http://127.0.0.1:7860
```

## Important licensing

The upstream CatVTON repository states that its demo and weights are for non-commercial use and uses a CC BY-NC-SA license. Do not ship this P0 package as a commercial product until the model/code/weights and every third-party dependency have been reviewed for commercial licensing.

## Architecture

```text
Web UI
  |
  v
app.py
  |
  +--> ProductService
  |
  +--> TryOnService
  |       |
  |       +--> AutoMasker
  |       +--> CatVTONPipeline
  |
  +--> UpscaleService
  |
  v
Result
```

## Next step: P1

P1 should be implemented only after P0 is running reliably. The highest-value feature is not a larger resize factor; it is geometric garment preservation.
