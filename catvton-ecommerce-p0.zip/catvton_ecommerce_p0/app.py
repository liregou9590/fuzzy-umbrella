import argparse
import os
from pathlib import Path

import gradio as gr
import torch
from huggingface_hub import snapshot_download

from model.pipeline import CatVTONPipeline
from model.cloth_masker import AutoMasker
from utils import init_weight_dtype
from services.tryon_service import TryOnService
from services.product_service import ProductService
from services.upscale_service import UpscaleService


def parse_args():
    p = argparse.ArgumentParser(description="CatVTON E-commerce P0")
    p.add_argument("--base_model_path", default="booksforcharlie/stable-diffusion-inpainting")
    p.add_argument("--resume_path", default="zhengchong/CatVTON")
    p.add_argument("--output_dir", default="resource/demo/output_p0")
    p.add_argument("--width", type=int, default=768)
    p.add_argument("--height", type=int, default=1024)
    p.add_argument("--mixed_precision", choices=["no", "fp16", "bf16"], default="bf16")
    p.add_argument("--device", default="cuda")
    p.add_argument("--port", type=int, default=7860)
    p.add_argument("--share", action="store_true")
    return p.parse_args()


args = parse_args()
Path(args.output_dir).mkdir(parents=True, exist_ok=True)

if args.device == "cuda" and not torch.cuda.is_available():
    raise RuntimeError("CUDA is not available. Use --device cpu only if you have a compatible CPU setup.")

repo_path = snapshot_download(repo_id=args.resume_path)

pipeline = CatVTONPipeline(
    base_ckpt=args.base_model_path,
    attn_ckpt=repo_path,
    attn_ckpt_version="mix",
    weight_dtype=init_weight_dtype(args.mixed_precision),
    use_tf32=(args.device == "cuda"),
    device=args.device,
)

automasker = AutoMasker(
    densepose_ckpt=os.path.join(repo_path, "DensePose"),
    schp_ckpt=os.path.join(repo_path, "SCHP"),
    device=args.device,
)

tryon = TryOnService(
    pipeline=pipeline,
    automasker=automasker,
    width=args.width,
    height=args.height,
    device=args.device,
)

product_service = ProductService()
upscale_service = UpscaleService()


def generate(person_path, cloth_path, cloth_type, steps, guidance, seed, output_size):
    if not person_path:
        raise gr.Error("请上传模特图。")
    if not cloth_path:
        raise gr.Error("请上传睡衣白底图。")

    try:
        product = product_service.prepare(cloth_path)

        result = tryon.generate(
            person_path=person_path,
            cloth_path=product["normalized_path"],
            cloth_type=cloth_type,
            steps=int(steps),
            guidance=float(guidance),
            seed=int(seed),
        )

        # P0: output-size control. Exact garment-pixel restoration is intentionally
        # not performed here because cloth-to-body geometric warping is required.
        result = upscale_service.process(result, output_size)

        return result, product["mask_path"]
    except Exception as exc:
        raise gr.Error(f"生成失败：{exc}") from exc


with gr.Blocks(title="AI 电商睡衣视觉工作台") as demo:
    gr.Markdown(
        """
        # AI 电商睡衣视觉工作台 · P0
        **产品白底图 + 模特图 → AI 换装 → 1K/2K 输出**

        P0 目标是先把 CatVTON 的核心换装链路稳定封装起来。
        """
    )

    with gr.Row():
        with gr.Column(scale=1):
            person = gr.Image(type="filepath", label="① 模特图")
            cloth = gr.Image(type="filepath", label="② 睡衣白底图")

            cloth_type = gr.Radio(
                ["upper", "lower", "overall"],
                value="overall",
                label="服装类型",
            )

            steps = gr.Slider(10, 100, value=50, step=5, label="Inference Steps")
            guidance = gr.Slider(0, 7.5, value=2.5, step=0.5, label="CFG")
            seed = gr.Number(value=42, precision=0, label="Seed")

            output_size = gr.Radio(
                ["1K", "2K", "原尺寸"],
                value="1K",
                label="输出",
            )

            generate_btn = gr.Button("一键生成", variant="primary")

        with gr.Column(scale=2):
            result = gr.Image(type="pil", label="生成结果")
            product_mask = gr.Image(type="filepath", label="产品白底 Mask（诊断）")

    generate_btn.click(
        generate,
        inputs=[person, cloth, cloth_type, steps, guidance, seed, output_size],
        outputs=[result, product_mask],
    )


if __name__ == "__main__":
    demo.queue().launch(
        server_name="0.0.0.0",
        server_port=args.port,
        share=args.share,
        show_error=True,
    )
