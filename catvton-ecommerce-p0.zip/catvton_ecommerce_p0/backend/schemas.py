from dataclasses import dataclass


@dataclass
class GenerateRequest:
    person_path: str
    cloth_path: str
    cloth_type: str = "overall"
    steps: int = 50
    guidance: float = 2.5
    seed: int = 42
    output_size: str = "1K"
