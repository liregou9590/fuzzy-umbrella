from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from uuid import uuid4


class JobStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


@dataclass
class Job:
    id: str
    status: JobStatus
    created_at: str
    result_path: str | None = None
    error: str | None = None


class JobStore:
    def __init__(self):
        self._jobs = {}

    def create(self):
        job = Job(
            id=uuid4().hex,
            status=JobStatus.QUEUED,
            created_at=datetime.utcnow().isoformat(),
        )
        self._jobs[job.id] = job
        return job

    def get(self, job_id):
        return self._jobs.get(job_id)
