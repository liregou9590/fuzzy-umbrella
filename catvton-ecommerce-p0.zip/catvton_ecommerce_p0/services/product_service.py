from pathlib import Path
from uuid import uuid4

import cv2
import numpy as np
from PIL import Image


class ProductService:
    """
    P0 product preparation for white-background product photos.

    This creates:
      - normalized RGB image
      - diagnostic product mask

    It deliberately does NOT claim pixel-perfect garment restoration.
    Exact restoration requires geometric warping of the garment onto the
    generated body, which is a P1 feature.
    """

    def __init__(self, work_dir="uploads/products"):
        self.work_dir = Path(work_dir)
        self.work_dir.mkdir(parents=True, exist_ok=True)

    def prepare(self, path: str):
        image = Image.open(path).convert("RGB")
        image = self._normalize_canvas(image)

        stem = uuid4().hex[:12]
        normalized_path = self.work_dir / f"{stem}_normalized.png"
        mask_path = self.work_dir / f"{stem}_mask.png"

        image.save(normalized_path)
        mask = self._white_background_mask(image)
        Image.fromarray(mask).save(mask_path)

        return {
            "normalized_path": str(normalized_path),
            "mask_path": str(mask_path),
        }

    @staticmethod
    def _normalize_canvas(image: Image.Image) -> Image.Image:
        # Keep original aspect ratio; CatVTON performs its own padding later.
        return image.convert("RGB")

    @staticmethod
    def _white_background_mask(image: Image.Image):
        arr = np.asarray(image).astype(np.uint8)

        # White/near-white background detection.
        # This is intentionally conservative to avoid eating light-colored
        # pajamas. The threshold can be tuned in P1 with segmentation.
        diff = 255 - arr
        distance = np.max(diff, axis=2)
        mask = (distance > 18).astype(np.uint8) * 255

        # Remove tiny noise.
        kernel = np.ones((3, 3), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        return mask
