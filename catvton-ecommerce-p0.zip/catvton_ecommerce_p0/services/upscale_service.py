from PIL import Image


class UpscaleService:
    """
    P0 output-size adapter.

    2K here means a 2K canvas/output target. A production-grade P1 should
    replace the resize operation with a dedicated super-resolution model.
    """

    def process(self, image: Image.Image, target: str):
        if target == "原尺寸":
            return image

        if target == "1K":
            target_h = 1024
        elif target == "2K":
            target_h = 2048
        else:
            raise ValueError(f"Unsupported output size: {target}")

        w, h = image.size
        scale = target_h / h
        target_w = max(1, round(w * scale))
        return image.resize((target_w, target_h), Image.Resampling.LANCZOS)
