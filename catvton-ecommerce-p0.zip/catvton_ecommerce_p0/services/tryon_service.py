from datetime import datetime
from pathlib import Path
from typing import Optional

import numpy as np
import torch
from PIL import Image
from diffusers.image_processor import VaeImageProcessor

from model.cloth_masker import vis_mask
from utils import resize_and_crop, resize_and_padding


class TryOnService:
    """Application-level wrapper around the original CatVTON pipeline."""

    def __init__(self, pipeline, automasker, width=768, height=1024, device="cuda"):
        self.pipeline = pipeline
        self.automasker = automasker
        self.width = width
        self.height = height
        self.device = device
        self.mask_processor = VaeImageProcessor(
            vae_scale_factor=8,
            do_normalize=False,
            do_binarize=True,
            do_convert_grayscale=True,
        )

    @staticmethod
    def _read_rgb(path):
        return Image.open(path).convert("RGB")

    @staticmethod
    def _read_optional_mask(mask_path):
        if not mask_path:
            return None
        mask = Image.open(mask_path).convert("L")
        if len(np.unique(np.asarray(mask))) == 1:
            return None
        arr = np.asarray(mask)
        arr[arr > 0] = 255
        return Image.fromarray(arr)

    def generate(
        self,
        person_path: str,
        cloth_path: str,
        cloth_type: str = "overall",
        steps: int = 50,
        guidance: float = 2.5,
        seed: int = 42,
        manual_mask_path: Optional[str] = None,
    ):
        person = resize_and_crop(self._read_rgb(person_path), (self.width, self.height))
        cloth = resize_and_padding(self._read_rgb(cloth_path), (self.width, self.height))

        mask = self._read_optional_mask(manual_mask_path)
        if mask is not None:
            mask = resize_and_crop(mask, (self.width, self.height))
        else:
            mask = self.automasker(person, cloth_type)["mask"]

        mask = self.mask_processor.blur(mask, blur_factor=9)

        generator = None
        if seed is not None and int(seed) >= 0:
            generator = torch.Generator(device=self.device).manual_seed(int(seed))

        with torch.inference_mode():
            result = self.pipeline(
                image=person,
                condition_image=cloth,
                mask=mask,
                num_inference_steps=int(steps),
                guidance_scale=float(guidance),
                generator=generator,
            )[0]

        return result
