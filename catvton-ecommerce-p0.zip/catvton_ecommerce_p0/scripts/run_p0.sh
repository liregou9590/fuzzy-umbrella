#!/usr/bin/env bash
set -e
python app.py --device cuda --mixed_precision bf16 --port 7860
