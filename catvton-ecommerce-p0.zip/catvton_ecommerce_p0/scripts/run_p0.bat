@echo off
setlocal
python app.py --device cuda --mixed_precision bf16 --port 7860
pause
