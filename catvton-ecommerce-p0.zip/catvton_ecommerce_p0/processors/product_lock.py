from PIL import Image
import numpy as np


def feather_mask(mask: Image.Image, radius: int = 3) -> Image.Image:
    """
    Utility for P1 compositing work.
    P0 does not use this to paste the original garment because the generated
    body geometry is different from the flat product photo.
    """
    import cv2

    arr = np.asarray(mask.convert("L"))
    if radius <= 0:
        return mask.convert("L")

    k = max(3, int(radius) * 2 + 1)
    if k % 2 == 0:
        k += 1
    arr = cv2.GaussianBlur(arr, (k, k), 0)
    return Image.fromarray(arr)


def mask_coverage(mask: Image.Image) -> float:
    arr = np.asarray(mask.convert("L"))
    return float((arr > 127).mean())
