from PIL import Image


def alpha_composite(base: Image.Image, overlay: Image.Image, mask: Image.Image):
    """
    Generic alpha composite helper.

    P0 does not invoke this for the garment because a flat product photo
    cannot be directly pasted over a posed human body without geometric
    warping.
    """
    base = base.convert("RGBA")
    overlay = overlay.convert("RGBA").resize(base.size)
    alpha = mask.convert("L").resize(base.size)
    overlay.putalpha(alpha)
    return Image.alpha_composite(base, overlay).convert("RGB")
