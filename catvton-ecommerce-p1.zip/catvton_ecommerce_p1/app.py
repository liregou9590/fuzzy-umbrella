import argparse
import os
from pathlib import Path

import gradio as gr
import torch
from huggingface_hub import snapshot_download

from model.pipeline import CatVTONPipeline
from model.cloth_masker import AutoMasker
from utils import init_weight_dtype

from services.tryon_service import TryOnService
from services.product_service import ProductService
from services.upscale_service import UpscaleService
from processors.garment_preservation import preserve_garment


def parse_args():
    p = argparse.ArgumentParser(description="CatVTON E-commerce P1")
    p.add_argument("--base_model_path", default="booksforcharlie/stable-diffusion-inpainting")
    p.add_argument("--resume_path", default="zhengchong/CatVTON")
    p.add_argument("--output_dir", default="resource/demo/output_p1")
    p.add_argument("--width", type=int, default=768)
    p.add_argument("--height", type=int, default=1024)
    p.add_argument("--mixed_precision", choices=["no", "fp16", "bf16"], default="bf16")
    p.add_argument("--device", default="cuda")
    p.add_argument("--port", type=int, default=7860)
    p.add_argument("--share", action="store_true")
    return p.parse_args()


args = parse_args()
Path(args.output_dir).mkdir(parents=True, exist_ok=True)

if args.device == "cuda" and not torch.cuda.is_available():
    raise RuntimeError("CUDA is not available.")

repo_path = snapshot_download(repo_id=args.resume_path)

pipeline = CatVTONPipeline(
    base_ckpt=args.base_model_path,
    attn_ckpt=repo_path,
    attn_ckpt_version="mix",
    weight_dtype=init_weight_dtype(args.mixed_precision),
    use_tf32=(args.device == "cuda"),
    device=args.device,
)

automasker = AutoMasker(
    densepose_ckpt=os.path.join(repo_path, "DensePose"),
    schp_ckpt=os.path.join(repo_path, "SCHP"),
    device=args.device,
)

tryon = TryOnService(
    pipeline=pipeline,
    automasker=automasker,
    width=args.width,
    height=args.height,
    device=args.device,
)
product_service = ProductService()
upscale = UpscaleService()


def generate(
    person_path,
    cloth_path,
    cloth_type,
    steps,
    guidance,
    seed,
    output_size,
    preservation_strength,
    manual_garment_mask,
):
    if not person_path:
        raise gr.Error("请上传模特图。")
    if not cloth_path:
        raise gr.Error("请上传睡衣白底图。")

    try:
        product = product_service.prepare(cloth_path)

        result, target_mask = tryon.generate(
            person_path=person_path,
            cloth_path=product["normalized_path"],
            cloth_type=cloth_type,
            steps=int(steps),
            guidance=float(guidance),
            seed=int(seed),
            manual_mask_path=manual_garment_mask,
        )

        # Product source of truth: original cutout, not an AI-regenerated garment.
        product_rgba = Image.open(product["cutout_path"]).convert("RGBA")
        result = preserve_garment(
            generated=result,
            product_rgba=product_rgba,
            target_garment_mask=target_mask,
            strength=float(preservation_strength),
        )

        result = upscale.process(result, output_size)
        return result, product["mask_path"], target_mask

    except Exception as exc:
        raise gr.Error(f"生成失败：{exc}") from exc


with gr.Blocks(title="AI 电商睡衣视觉工作台 P1") as demo:
    gr.Markdown(
        """
        # AI 电商睡衣视觉工作台 · P1
        **白底睡衣 → 自动轮廓 → 模特换装 → 产品细节保护 → 2K**

        P1 增加了产品轮廓提取、产品源图保存、目标服装区域保护和保守式几何贴合。
        """
    )

    with gr.Row():
        with gr.Column(scale=1):
            person = gr.Image(type="filepath", label="① 模特图")
            cloth = gr.Image(type="filepath", label="② 睡衣白底图")

            cloth_type = gr.Radio(
                ["upper", "lower", "overall"],
                value="overall",
                label="服装类型",
            )

            manual_mask = gr.Image(
                type="filepath",
                label="③ 可选：手工服装 Mask（白色=需要保护）",
            )

            steps = gr.Slider(10, 100, value=50, step=5, label="Inference Steps")
            guidance = gr.Slider(0, 7.5, value=2.5, step=0.5, label="CFG")
            seed = gr.Number(value=42, precision=0, label="Seed")

            preservation = gr.Slider(
                0,
                1,
                value=0.85,
                step=0.05,
                label="原产品细节保护强度",
            )

            output_size = gr.Radio(
                ["1K", "2K", "原尺寸"],
                value="2K",
                label="输出",
            )

            generate_btn = gr.Button("一键生成", variant="primary")

        with gr.Column(scale=2):
            result = gr.Image(type="pil", label="最终结果")
            product_mask = gr.Image(type="filepath", label="① 产品轮廓 Mask")
            target_mask = gr.Image(type="pil", label="② 模特服装目标 Mask")

    generate_btn.click(
        generate,
        inputs=[
            person,
            cloth,
            cloth_type,
            steps,
            guidance,
            seed,
            output_size,
            preservation,
            manual_mask,
        ],
        outputs=[result, product_mask, target_mask],
    )


if __name__ == "__main__":
    demo.queue().launch(
        server_name="0.0.0.0",
        server_port=args.port,
        share=args.share,
        show_error=True,
    )
