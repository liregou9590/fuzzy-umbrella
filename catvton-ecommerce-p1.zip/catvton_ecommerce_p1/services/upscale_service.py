from PIL import Image


class UpscaleService:
    """
    P1 keeps the interface simple. It uses high-quality Lanczos resizing.
    Replace the implementation with a licensed SR model for true detail
    reconstruction in a later production build.
    """

    def process(self, image: Image.Image, target="2K"):
        if target == "原尺寸":
            return image

        target_h = {"1K": 1024, "2K": 2048}[target]
        w, h = image.size
        target_w = max(1, round(w * target_h / h))
        return image.resize((target_w, target_h), Image.Resampling.LANCZOS)
