from pathlib import Path
from uuid import uuid4

import cv2
import numpy as np
from PIL import Image


class ProductService:
    """Prepare a white-background pajama image and create a conservative garment mask."""

    def __init__(self, work_dir="uploads/products"):
        self.work_dir = Path(work_dir)
        self.work_dir.mkdir(parents=True, exist_ok=True)

    def prepare(self, path: str):
        image = Image.open(path).convert("RGB")
        mask = self._garment_mask(image)

        stem = uuid4().hex[:12]
        original_path = self.work_dir / f"{stem}_original.png"
        normalized_path = self.work_dir / f"{stem}_normalized.png"
        mask_path = self.work_dir / f"{stem}_mask.png"
        cutout_path = self.work_dir / f"{stem}_cutout.png"

        image.save(original_path)
        image.save(normalized_path)

        Image.fromarray(mask).save(mask_path)
        rgba = np.dstack([np.asarray(image), mask])
        Image.fromarray(rgba.astype(np.uint8), "RGBA").save(cutout_path)

        return {
            "original_path": str(original_path),
            "normalized_path": str(normalized_path),
            "mask_path": str(mask_path),
            "cutout_path": str(cutout_path),
        }

    @staticmethod
    def _garment_mask(image: Image.Image) -> np.ndarray:
        """
        Conservative foreground extraction for clean white-background product shots.

        This is intentionally conservative: very light garments can overlap with
        the white background, so P1 provides a manual-mask override in the UI.
        """
        arr = np.asarray(image).astype(np.uint8)
        gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)

        # Difference from white background.
        diff = 255 - gray
        mask = (diff > 12).astype(np.uint8) * 255

        # Keep the largest connected foreground components.
        num, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
        if num > 1:
            areas = stats[1:, cv2.CC_STAT_AREA]
            order = np.argsort(areas)[::-1]
            keep = set((order[:min(8, len(order))] + 1).tolist())
            mask = np.where(np.isin(labels, list(keep)), 255, 0).astype(np.uint8)

        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))

        # Fill small internal holes while preserving the garment silhouette.
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        filled = np.zeros_like(mask)
        if contours:
            contours = sorted(contours, key=cv2.contourArea, reverse=True)
            for c in contours[:8]:
                if cv2.contourArea(c) >= max(32, mask.size * 0.00005):
                    cv2.drawContours(filled, [c], -1, 255, thickness=cv2.FILLED)

        return filled if filled.any() else mask

    @staticmethod
    def feather(mask: Image.Image, radius: int = 3) -> Image.Image:
        arr = np.asarray(mask.convert("L"))
        k = max(3, radius * 2 + 1)
        if k % 2 == 0:
            k += 1
        return Image.fromarray(cv2.GaussianBlur(arr, (k, k), 0))
