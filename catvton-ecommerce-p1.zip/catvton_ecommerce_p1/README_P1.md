# CatVTON E-commerce P1 — Product Preservation

## P1 capabilities

- Upload a white-background pajama/product image.
- Automatically estimate the garment silhouette.
- Save the original product pixels as the product source of truth.
- Use CatVTON for human try-on.
- Use the generated garment target mask.
- Conservatively align the original garment cutout to the generated target mask.
- Blend original garment pixels back with adjustable preservation strength.
- Export a 2K output canvas.

## Important limitation

This is a P1 engineering implementation, not a claim of mathematically exact 1:1 reproduction.

A flat catalog garment and a garment on a human body have different geometry. The included `align_product_to_target()` uses bounding-box scaling only. It is appropriate as a baseline for simple front-facing shots, but it will not correctly model:

- sleeves wrapping around arms
- folds
- perspective
- body occlusion
- side views
- loose pajamas
- complex lace edges

For production quality, replace that function with a dense cloth-warp/correspondence stage.

## Files

```text
app.py
services/
  product_service.py
  tryon_service.py
  upscale_service.py
processors/
  garment_preservation.py
```

## Run

Install the original CatVTON dependencies first, then install the P1 additions:

```bash
pip install opencv-python gradio
```

Run:

```bash
python app.py --device cuda --mixed_precision bf16 --port 7860
```

If BF16 is unsupported:

```bash
python app.py --device cuda --mixed_precision fp16 --port 7860
```

Open:

```text
http://127.0.0.1:7860
```

## Workflow

1. Upload a clean white-background pajama image.
2. Upload a model photo.
3. Select `overall` for a pajama set/full-body garment.
4. Optionally provide a hand-made garment mask.
5. Set preservation strength around `0.75–0.9`.
6. Select `2K`.
7. Generate.

## Best input recommendations

Product image:

- pure or near-white background
- full garment visible
- minimal occlusion
- high resolution
- front or near-front view
- avoid shadows crossing the garment

Model image:

- full body or enough body area for the garment
- standing pose is easier
- avoid crossed arms over the garment
- good lighting
- minimal motion blur

## Why original product pixels are not pasted blindly

The source pajama is a flat image. The generated human body introduces a new silhouette and perspective. Blindly pasting the source pixels creates floating rectangles or wrong sleeves. P1 therefore limits the source-pixel blend to the target garment mask and uses a conservative bounding-box alignment.

## Commercial use warning

Check the upstream CatVTON code, weights, base model and every dependency before commercial deployment. The upstream project currently states non-commercial licensing restrictions. P1 is an engineering prototype, not a commercial-license grant.
