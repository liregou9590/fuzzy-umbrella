from pathlib import Path

import cv2
import numpy as np
from PIL import Image


def extract_garment_features(image: Image.Image, mask: Image.Image):
    """
    Store product pixels/features that can be used by P1 compositing.

    The returned image is the original product image; no generative operation
    is performed on it. This is the source of truth for color/print/button data.
    """
    rgb = np.asarray(image.convert("RGB"))
    m = np.asarray(mask.convert("L"))
    return {
        "rgb": rgb.copy(),
        "mask": m.copy(),
        "mean_color": rgb[m > 127].mean(axis=0).tolist() if np.any(m > 127) else [255, 255, 255],
    }


def align_product_to_target(product_rgba: Image.Image, target_mask: Image.Image):
    """
    Conservative geometric alignment helper.

    It scales/translates the flat product cutout to the target garment mask's
    bounding box. This is NOT a full cloth-warp solver; use it only as a
    fallback for simple front-facing catalog poses.
    """
    src = np.asarray(product_rgba.convert("RGBA"))
    dst_mask = np.asarray(target_mask.convert("L"))

    ys, xs = np.where(dst_mask > 127)
    if len(xs) == 0:
        return None

    tx0, tx1 = xs.min(), xs.max()
    ty0, ty1 = ys.min(), ys.max()

    alpha = src[:, :, 3]
    sy, sx = np.where(alpha > 127)
    if len(sx) == 0:
        return None

    sx0, sx1 = sx.min(), sx.max()
    sy0, sy1 = sy.min(), sy.max()

    crop = src[sy0:sy1 + 1, sx0:sx1 + 1]
    width = max(1, tx1 - tx0 + 1)
    height = max(1, ty1 - ty0 + 1)

    resized = cv2.resize(crop, (width, height), interpolation=cv2.INTER_LANCZOS4)

    canvas = np.zeros((dst_mask.shape[0], dst_mask.shape[1], 4), dtype=np.uint8)
    canvas[ty0:ty1 + 1, tx0:tx1 + 1] = resized

    # Clip the pasted alpha by the target garment mask.
    canvas[:, :, 3] = np.minimum(canvas[:, :, 3], dst_mask)
    return Image.fromarray(canvas, "RGBA")


def preserve_garment(
    generated: Image.Image,
    product_rgba: Image.Image,
    target_garment_mask: Image.Image,
    strength: float = 0.85,
):
    """
    Blend a geometrically aligned product cutout into a generated image.

    This is deliberately conservative. A real cloth warp can be plugged in
    later without changing the public API.
    """
    aligned = align_product_to_target(product_rgba, target_garment_mask)
    if aligned is None:
        return generated

    base = generated.convert("RGBA")
    overlay = aligned.convert("RGBA")

    alpha = np.asarray(overlay.getchannel("A")).astype(np.float32) / 255.0
    alpha *= float(np.clip(strength, 0.0, 1.0))

    # Feather the seam.
    alpha = cv2.GaussianBlur(alpha, (0, 0), 1.2)
    overlay.putalpha(Image.fromarray(np.clip(alpha * 255, 0, 255).astype(np.uint8)))

    return Image.alpha_composite(base, overlay).convert("RGB")
